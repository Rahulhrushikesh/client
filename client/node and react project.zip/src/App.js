import ChatContainer from "./components/ChatContainer.js";

function App() {
  return (
    <div style = {{backgroundColor: "#799c86" , height: "100vh"}} >
      <ChatContainer/>
      </div>
  )
}
export default App;